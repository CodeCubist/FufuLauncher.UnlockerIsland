﻿using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace LauncherPro.Models
{
    public class AppConfig : INotifyPropertyChanged
    {
        private string _gamePath = "";
        private string _dllPath = "";
        private bool _enableInjection = true;
        private bool _autoClose = false;
        private bool _useCustomDll = false;
        private bool _isPopup = false;
        private int _fullSize = 1;
        private int _height = 1080;
        private int _width = 1920;
        private bool _enableScript = false;
        private string _scriptContent = "";

        public string GamePath
        {
            get => _gamePath;
            set { _gamePath = value; OnPropertyChanged(); }
        }

        public string DllPath
        {
            get => _dllPath;
            set { _dllPath = value; OnPropertyChanged(); }
        }

        public bool EnableInjection
        {
            get => _enableInjection;
            set { _enableInjection = value; OnPropertyChanged(); }
        }

        public bool AutoClose
        {
            get => _autoClose;
            set { _autoClose = value; OnPropertyChanged(); }
        }

        public bool UseCustomDll
        {
            get => _useCustomDll;
            set { _useCustomDll = value; OnPropertyChanged(); }
        }
        
        public bool IsPopup
        {
            get => _isPopup;
            set { _isPopup = value; OnPropertyChanged(); }
        }
        
        public int FullSize
        {
            get => _fullSize;
            set { _fullSize = value; OnPropertyChanged(); }
        }
        
        public int Height
        {
            get => _height;
            set { _height = value; OnPropertyChanged(); }
        }
        
        public int Width
        {
            get => _width;
            set { _width = value; OnPropertyChanged(); }
        }
        
        public bool EnableScript
        {
            get => _enableScript;
            set { _enableScript = value; OnPropertyChanged(); }
        }
        
        public string ScriptContent
        {
            get => _scriptContent;
            set { _scriptContent = value; OnPropertyChanged(); }
        }

        public event PropertyChangedEventHandler? PropertyChanged;
        
        protected virtual void OnPropertyChanged([CallerMemberName] string? propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}