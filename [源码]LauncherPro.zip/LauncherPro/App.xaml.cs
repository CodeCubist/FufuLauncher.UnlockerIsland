﻿using System.Windows;
using HandyControl.Themes;
using HandyControl.Tools;
using LauncherPro.Models;

namespace LauncherPro
{
    public partial class App : Application
    {
        protected override void OnStartup(StartupEventArgs e)
        {
            base.OnStartup(e);
            ConfigHelper.Instance.SetLang("zh-cn");
            ThemeManager.Current.ApplicationTheme = ApplicationTheme.Dark;
            var config = new AppConfig();
            var mainWindow = new MainWindow();
            mainWindow.DataContext = config;
            mainWindow.Show();
        }
    }
}