﻿using System.Windows;
using LauncherPro.Pages;

namespace LauncherPro
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            NavigateToHome();
        }

        private void NavigateToHome()
        {
            if (MainFrame != null)
            {
                MainFrame.Navigate(new HomePage());
            }
        }

        private void NavigateToSettings()
        {
            if (MainFrame != null)
            {
                MainFrame.Navigate(new SettingsPage());
            }
        }

        private void HomeNavBtn_Checked(object sender, RoutedEventArgs e)
        {
            NavigateToHome();
        }

        private void SettingsNavBtn_Checked(object sender, RoutedEventArgs e)
        {
            NavigateToSettings();
        }
    }
}