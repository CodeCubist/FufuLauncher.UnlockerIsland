﻿using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using LauncherPro.Models;

namespace LauncherPro.Services
{
    public static class LauncherService
    {
        [DllImport("Launcher.dll", CharSet = CharSet.Unicode)]
        private static extern int LaunchGameAndInject(string gamePath, string dllPath, string commandLineArgs, StringBuilder errorMessage, int errorMessageSize);

        [DllImport("Launcher.dll", CharSet = CharSet.Unicode)]
        private static extern int GetDefaultDllPath(StringBuilder dllPath, int dllPathSize);

        [DllImport("Launcher.dll", CharSet = CharSet.Unicode)]
        public static extern bool ValidateGamePath(string gamePath);

        [DllImport("Launcher.dll", CharSet = CharSet.Unicode)]
        public static extern bool ValidateDllPath(string dllPath);

        public static LaunchResult LaunchGame(AppConfig config)
        {
            try
            {
                if (!ValidateGamePath(config.GamePath))
                {
                    return new LaunchResult { Success = false, ErrorMessage = "游戏路径无效或文件不存在" };
                }

                string dllPath = config.DllPath;
                if (config.EnableInjection)
                {
                    if (string.IsNullOrEmpty(dllPath) || !ValidateDllPath(dllPath))
                    {
                        return new LaunchResult { Success = false, ErrorMessage = "DLL路径无效或文件不存在" };
                    }
                }
                else
                {
                    dllPath = "";
                }
                
                string commandLineArgs = BuildCommandLineArgs(config);
                var errorMessage = new StringBuilder(256);
                int result = LaunchGameAndInject(config.GamePath, dllPath, commandLineArgs, errorMessage, errorMessage.Capacity);
                if (result == 0 && config.EnableScript && !string.IsNullOrWhiteSpace(config.ScriptContent))
                {
                    ExecuteScript(config.ScriptContent);
                }

                return result switch
                {
                    0 => new LaunchResult { Success = true },
                    1 => new LaunchResult { Success = false, ErrorMessage = "游戏路径验证失败" },
                    2 => new LaunchResult { Success = false, ErrorMessage = "DLL路径验证失败" },
                    3 => new LaunchResult { Success = false, ErrorMessage = "无法创建游戏进程" },
                    4 => new LaunchResult { Success = false, ErrorMessage = "DLL注入失败" },
                    _ => new LaunchResult { Success = false, ErrorMessage = $"未知错误: {result}" }
                };
            }
            catch (Exception ex)
            {
                return new LaunchResult { Success = false, ErrorMessage = $"异常: {ex.Message}" };
            }
        }

        private static string BuildCommandLineArgs(AppConfig config)
        {
            var builder = new CommandLineBuilder()
                .AppendIf("-popupwindow", config.IsPopup)
                .Append("-screen-fullscreen", config.FullSize)
                .Append("-screen-height", config.Height)
                .Append("-screen-width", config.Width);
            
            return builder.ToString();
        }
        private static void ExecuteScript(string scriptContent)
        {
            try
            {
                string tempScriptPath = Path.GetTempFileName() + ".bat";
                File.WriteAllText(tempScriptPath, scriptContent, Encoding.Default);
                ProcessStartInfo psi = new ProcessStartInfo
                {
                    FileName = tempScriptPath,
                    UseShellExecute = false,
                    CreateNoWindow = true,
                    WorkingDirectory = Path.GetTempPath()
                };
                Process process = new Process { StartInfo = psi };
                process.Start();
                process.EnableRaisingEvents = true;
                process.Exited += (sender, e) =>
                {
                    try
                    {
                        File.Delete(tempScriptPath);
                    }
                    catch
                    {

                    }
                    process.Dispose();
                };
            }
            catch
            {

            }
        }

        public static string? GetDefaultDllPath()
        {
            try
            {
                var pathBuilder = new StringBuilder(260);
                int result = GetDefaultDllPath(pathBuilder, pathBuilder.Capacity);
                return result == 0 ? pathBuilder.ToString() : null;
            }
            catch (Exception)
            {
                return null;
            }
        }
        
        private class CommandLineBuilder
        {
            private readonly StringBuilder _builder = new StringBuilder();

            public CommandLineBuilder AppendIf(string argument, bool condition)
            {
                if (condition)
                {
                    _builder.Append(argument);
                    _builder.Append(' ');
                }
                return this;
            }

            public CommandLineBuilder Append(string argument, object value)
            {
                _builder.Append(argument);
                _builder.Append(' ');
                _builder.Append(value);
                _builder.Append(' ');
                return this;
            }

            public override string ToString()
            {
                return _builder.ToString().Trim();
            }
        }
    }

    public class LaunchResult
    {
        public bool Success { get; set; }
        public string ErrorMessage { get; set; } = string.Empty;
    }
}