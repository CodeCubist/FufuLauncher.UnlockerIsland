﻿using System.IO;
using System.Text.Json;
using LauncherPro.Models;

namespace LauncherPro.Services
{
    public static class ConfigManager
    {
        private static readonly string ConfigPath = Path.Combine(
            Directory.GetCurrentDirectory(), "Config", "launcher_config.json");

        public static AppConfig LoadConfig(string? filePath = null)
        {
            var path = filePath ?? ConfigPath;
            
            try
            {
                if (File.Exists(path))
                {
                    var json = File.ReadAllText(path);
                    return JsonSerializer.Deserialize<AppConfig>(json) ?? new AppConfig();
                }
            }
            catch
            {

            }
            
            return new AppConfig();
        }

        public static void SaveConfig(AppConfig config, string? filePath = null)
        {
            var path = filePath ?? ConfigPath;
            var directory = Path.GetDirectoryName(path);
            
            if (!string.IsNullOrEmpty(directory) && !Directory.Exists(directory))
            {
                Directory.CreateDirectory(directory);
            }

            var options = new JsonSerializerOptions { WriteIndented = true };
            var json = JsonSerializer.Serialize(config, options);
            File.WriteAllText(path, json);
        }

        public static string GetConfigPath()
        {
            return ConfigPath;
        }
    }
}