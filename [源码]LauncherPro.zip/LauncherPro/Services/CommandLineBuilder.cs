﻿using System.Text;

namespace LauncherPro.Services
{
    public class CommandLineBuilder
    {
        private readonly StringBuilder _builder = new StringBuilder();

        public CommandLineBuilder AppendIf(string argument, bool condition)
        {
            if (condition)
            {
                _builder.Append(argument);
                _builder.Append(' ');
            }
            return this;
        }

        public CommandLineBuilder Append(string argument, object value)
        {
            _builder.Append(argument);
            _builder.Append(' ');
            _builder.Append(value);
            _builder.Append(' ');
            return this;
        }

        public override string ToString()
        {
            return _builder.ToString().Trim();
        }
    }
}