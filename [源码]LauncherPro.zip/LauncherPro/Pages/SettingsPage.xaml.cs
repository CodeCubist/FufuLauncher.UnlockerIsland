﻿using System.Windows.Controls;

namespace LauncherPro.Pages
{
    public partial class SettingsPage : Page
    {
        public SettingsPage()
        {
            InitializeComponent();
        }
        
    }
}