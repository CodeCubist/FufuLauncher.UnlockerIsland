﻿using System.IO;
using System.Windows;
using System.Windows.Controls;
using Microsoft.Win32;
using LauncherPro.Models;
using LauncherPro.Services;
using System.Diagnostics;

namespace LauncherPro.Pages
{
    public partial class HomePage : Page
    {
        private AppConfig Config => (AppConfig)DataContext;

        public HomePage()
        {
            InitializeComponent();
            DataContext = new AppConfig();
            LoadDefaultPaths();
        }

        private void LoadDefaultPaths()
        {
            if (string.IsNullOrEmpty(Config.GamePath))
            {
                var gamePath = DetectGamePath();
                if (!string.IsNullOrEmpty(gamePath))
                {
                    Config.GamePath = gamePath;
                    ShowStatus($"已自动检测到游戏路径: {Path.GetFileName(gamePath)}", MessageType.Success);
                }
            }
            Config.EnableInjection = true;
            if (string.IsNullOrEmpty(Config.DllPath))
            {
                var defaultDllPath = LauncherService.GetDefaultDllPath();
                if (!string.IsNullOrEmpty(defaultDllPath))
                {
                    Config.DllPath = defaultDllPath;
                }
            }
        }
        
        private void SwitchToolButton_Click(object sender, RoutedEventArgs e)
        {
            string toolName = "Genshin_StarRail_fps_unlocke_Max.exe";
            string toolPath = Path.Combine(Directory.GetCurrentDirectory(), toolName);
    
            if (!File.Exists(toolPath))
            {
                ShowStatus($"未找到旧工具文件: {toolName}", MessageType.Error);
                return;
            }

            try
            {
                var button = sender as Button;
                if (button != null)
                {
                    button.IsEnabled = false;
                    button.Content = "启动中...";
                }
                Process.Start(new ProcessStartInfo
                {
                    FileName = toolPath,
                    UseShellExecute = true
                });

                ShowStatus("旧工具启动成功，正在关闭启动器...", MessageType.Success);
                Task.Delay(1000).ContinueWith(_ =>
                {
                    Application.Current.Dispatcher.Invoke(() =>
                    {
                        Application.Current?.MainWindow?.Close();
                    });
                });
            }
            catch (Exception ex)
            {
                ShowStatus($"启动旧工具失败: {ex.Message}", MessageType.Error);
                var button = sender as Button;
                if (button != null)
                {
                    button.IsEnabled = true;
                    button.Content = "切换旧工具";
                }
            }
        }

        private string DetectGamePath()
        {
            var genshinPath = GetGenshinPathFromRegistry();
            if (!string.IsNullOrEmpty(genshinPath) && File.Exists(genshinPath))
            {
                return genshinPath;
            }

            return string.Empty;
        }

        private string GetGenshinPathFromRegistry()
        {
            try
            {
                using (var key = Registry.CurrentUser.OpenSubKey(@"Software\miHoYo\HYP\1_1\hk4e_cn"))
                {
                    if (key != null)
                    {
                        var value = key.GetValue("GameInstallPath");
                        if (value != null)
                        {
                            var installPath = value.ToString();
                            if (!string.IsNullOrEmpty(installPath))
                            {
                                var exePath = Path.Combine(installPath, "YuanShen.exe");
                                if (File.Exists(exePath)) return exePath;

                                var subDirPath = Path.Combine(installPath, "Genshin Impact Game", "YuanShen.exe");
                                if (File.Exists(subDirPath)) return subDirPath;
                            }
                        }
                    }
                }
            }
            catch
            {
                
            }
            return string.Empty;
        }

        private void BrowseGamePath_Click(object sender, RoutedEventArgs e)
        {
            var openFileDialog = new OpenFileDialog
            {
                Filter = "可执行文件 (*.exe)|*.exe",
                Title = "选择游戏执行文件"
            };

            if (openFileDialog.ShowDialog() == true)
            {
                Config.GamePath = openFileDialog.FileName;
            }
        }

        private async void LaunchGame_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrEmpty(Config.GamePath))
            {
                ShowStatus("请选择有效的游戏执行文件路径", MessageType.Error);
                return;
            }

            if (!File.Exists(Config.GamePath))
            {
                ShowStatus("游戏执行文件不存在，请重新选择", MessageType.Error);
                return;
            }
            
            if (string.IsNullOrEmpty(Config.DllPath))
            {
                ShowStatus("请选择有效的 DLL 路径进行注入", MessageType.Error);
                return;
            }

            if (!File.Exists(Config.DllPath))
            {
                ShowStatus("DLL 文件不存在，请重新选择", MessageType.Error);
                return;
            }
            
            var button = sender as Button;
            if (button != null)
            {
                button.IsEnabled = false;
                button.Content = "启动中...";
            }

            try
            {
                var result = LauncherService.LaunchGame(Config);
                
                if (result.Success)
                {
                    ShowStatus("游戏启动成功", MessageType.Success);
                    
                    if (Config.AutoClose)
                    {
                        await System.Threading.Tasks.Task.Delay(2000);
                        Application.Current?.MainWindow?.Close();
                    }
                }
                else
                {
                    ShowStatus($"启动失败: {result.ErrorMessage}", MessageType.Error);
                }
            }
            finally
            {
                if (button != null)
                {
                    button.IsEnabled = true;
                    button.Content = "启动游戏";
                }
            }
        }

        private void ShowStatus(string message, MessageType type)
        {
            StatusText.Text = message;
            StatusNotification.Visibility = Visibility.Visible;
            switch (type)
            {
                case MessageType.Success:
                    StatusNotification.Background = new System.Windows.Media.SolidColorBrush(
                        System.Windows.Media.Color.FromArgb(255, 45, 125, 80));
                    break;
                case MessageType.Error:
                    StatusNotification.Background = new System.Windows.Media.SolidColorBrush(
                        System.Windows.Media.Color.FromArgb(255, 200, 60, 60));
                    break;
                default:
                    StatusNotification.Background = new System.Windows.Media.SolidColorBrush(
                        System.Windows.Media.Color.FromArgb(255, 50, 50, 50));
                    break;
            }
        }

        private enum MessageType
        {
            Info,
            Success,
            Warning,
            Error
        }
    }
}